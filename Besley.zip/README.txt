Thank you for buying Besley* by indestructible type* (https://indestructible-type.github.io)!

This is verson 1.0

To download a newer version of this font, please go to this secret link:
https://indestructible-type.github.io/Robert0105.html

To use this font family on your website paste the following into the <head>:
<link rel="stylesheet" href="https://indestructible-type.github.io/fonts/stylesheet.css" type="text/css" charset="utf-8" />

Then, in your CSS, set the font-family to "besley" for the book and bold versions, 
and to "besleymedium" for the medium versions.

If you have any questions, feel free to contact me at indestructibletype@gmail.com


Thanks!