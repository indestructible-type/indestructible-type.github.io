Thank you for downloading Renner* by indestructible type* (https://indestructible-type.github.io)!

This is verson 2.1

To download a newer version of this font, please go to this secret link:
https://indestructible-type.github.io/Paul424242.html

To use this font family on your website paste the following into the <head>:
<link rel="stylesheet" href="https://indestructible-type.github.io/fonts/stylesheet.css" type="text/css" charset="utf-8" />

Then, in your CSS, set the font-family to "renner" for the book and bold versions, 
and to "rennerlight", "rennermedium", and "rennerblack" for the other versions.

If you have any questions, feel free to contact me at indestructibletype@gmail.com


Thanks!